    <!--Warren Peterson-03/20/2020-->
    <!--GCU__CST_126__Blog Project-->
    <!--This is my own work-->
    
    <!--Navbar Element-->
<div class="navbar">

	<div class="logo_div">
		<a href="index.php"><h1>Warren Blog</h1></a>
	</div>
	<div>
		
	</div>
	<form action="searchHandler.php">
	<ul>
		
	  <li><input type ="text" name ="name" class="searchbar" placeholder="Search..."></input></li>
	  <li><input type ="submit" class="search_btn" value="search"></input></li>

	  <li><a class="active" href="home_page.html">Home</a></li>
	  <li><a href="index.php">Main Menu</a></li>
	  <li><a href="login.php">Log In </a></li>
	  <li><a href="register.php">Registration</a></li>
	</ul>
</form>
</div>