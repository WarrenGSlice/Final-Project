<html>
<?php
	//**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/12/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //**Search Bar Handler Script**********/

require_once ('userDataService.php');



// get the search term from the input form
$searchPhrase = $_GET['name'];

//create an instance of the businessService
$bs = new UserDataService();

//the find method returns an array of person
$posts = $bs->searchPosts($searchPhrase);



?>
<!--<h2>Search Results</h2>
<h3><?php /* echo "<br>You Searched for: " . $_GET['name'] . "<br>";*/ ?></h3>
<h3>Here is what we found: </h3>-->

<?php
if ($posts){
    //We got some results
    include ('_displaySearchResults.php');
}else{
    echo "No posts found here like that<br>";
}
?>
</html>