<!-- The first include should be config.php -->
<?php
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/20/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //**********Main Blog Page*************/
?>
<?php require_once('config.php'); 
$page_name ="Warren Blog | Home";?>

<!-- config.php should be here as the first include  -->

<?php require_once( ROOT_PATH . '/public_functions.php') ?>

<?php require_once( ROOT_PATH . '/registration_login.php') ?>

<!-- Retrieve all posts from database  -->
<?php $posts = getPublishedPosts(); ?>

<?php require_once( ROOT_PATH . '/head_section.php') ?>
	<title><?php echo $page_name;
	        $page_name ="Warren Blog | Home"; 
	        $access_number = visitor($page_name); ?></title>
</head>
<body>
	<!-- container - wraps whole page -->
	<div class="container">
		<!-- navbar -->
		<?php include( ROOT_PATH . '/navbar.php') ?>
		<!-- // navbar -->

		<!-- banner -->
		<?php include( ROOT_PATH . '/banner.php') ?>
		<!-- // banner -->

		<!-- Page content -->
		<div class="content">
			<h2 class="content-title">Recent Posts</h2>
			<hr>
			<!-- more content still to come here ... -->
        <script async src="https://cse.google.com/cse.js?cx=2acd7066ecc8bda83"></script>
<div class="gcse-search"></div>
			<!-- Add this ... -->
			<?php foreach ($posts as $post): ?>
				<div class="post" style="margin-left: 0px;">
					<img src="<?php echo BASE_URL . '/images/' . $post['image']; ?>" class="post_image" alt="">
					<!-- Added this if statement... -->
					<?php if (isset($post['topic']['name'])): ?>
						<a 
							href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $post['topic']['id'] ?>"
							class="btn category">
							<?php echo $post['topic']['name'] ?>
						</a>
					<?php endif ?>

					<a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
						<div class="post_info">
							<h3><?php echo $post['title'] ?></h3>
							<div class="info">
								<span><?php echo date("F j, Y ", strtotime($post["created_at"])); ?></span>
								<span class="read_more">Read more...</span>
							</div>
						</div>
					</a>
				</div>
			<?php endforeach ?>

		</div>
		<!-- // Page content -->

		<!-- footer -->
		<?php include( ROOT_PATH . '/footer.php') ?>
		<!-- // footer -->