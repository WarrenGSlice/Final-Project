<?php
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/21/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //******Single Post Pages**************/
?>
<?php  include('config.php'); ?>
<?php  include('public_functions.php'); ?>
<?php 
	if (isset($_GET['post-slug'])) {
		$post = getPost($_GET['post-slug']);
	}
	$topics = getAllTopics();
?>
<?php include('head_section.php'); ?>
<title> <?php echo $post['title'] ?> | Warren Blog</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
</head>
<body>
<div class="container">
	<!-- Navbar -->
		<?php include( ROOT_PATH . '/navbar.php'); ?>
	<!-- // Navbar -->
	
	<div class="content" >
		<!-- Page wrapper -->
		<div class="post-wrapper">
			<!-- full post div -->
			<div class="full-post-div">
			<?php if ($post['published'] == false): ?>
				<h2 class="post-title">Sorry... This post has not been published</h2>
			<?php else: ?>
				<h2 class="post-title"><?php echo $post['title']; ?></h2>
				<div class="post-body-div">
					<?php echo html_entity_decode($post['body']); ?>
				</div>
			<?php endif ?>
			</div>
			<!-- // full post div -->
			<a href="https://twitter.com/intent/tweet?screen_name=WarrenGFooFight&ref_src=twsrc%5Etfw" 
			    class="twitter-mention-button" data-size="large" data-text="Tag Post" data-related="WarrenGFooFight" 
			    data-lang="en" data-show-count="false">Tweet to @WarrenGFooFight</a>
			    <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
			<!-- comments section -->
			
			<br />
  			<h2 align="left" style="padding-left: 175px; font-weight: bold;"><a href="#">Post a Comment</a></h2>
  			<br />
  			<div class="post-wrapper">
   				<form method="POST" id="comment_form">
    				<div class="form-group">
     					<input type="text" name="comment_name" id="comment_name" class="form-control" placeholder="Enter Name" />
    				</div>
    				<div class="form-group">
     					<textarea name="comment_content" id="comment_content" class="form-control" placeholder="Enter Comment" rows="5"></textarea>
    				</div>
    				<div class="form-group">
     					<input type="hidden" name="comment_id" id="comment_id" value="<?php echo $comment_id?>" />
     					<input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
    				</div>
   				</form>
   				<span id="comment_message"></span>
   				<br />
   				<div id="display_comment">
   				
   				</div>
  			</div>
			
			<!--  coming soon ...  -->
		</div>
		<!-- // Page wrapper -->

		<!-- post sidebar -->
		<div class="post-sidebar">
			<div class="card">
				<div class="card-header">
					<h2>Topics</h2>
				</div>
				<div class="card-content">
					<?php foreach ($topics as $topic): ?>
						<a 
							href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $topic['id'] ?>">
							<?php echo $topic['name']; ?>
						</a> 
					<?php endforeach ?>
				</div>
			</div>
			<div class="card">
				<h2>Voting System</h2>
				<div class="card-header">
					
					<img src="img.png" >
					<div class="card-content">

						<button id="likebtn">
							<i class="fa fa-thumbs-up"></i>
						</button>
						<i id="input1" value="0" style="font-size: 25px; color: #12ff00; width: 50px; border: none; background: none; pointer-events: none; "></i>

						<div class="voting">
						<button id="dislikebtn">
							<i class="fa fa-thumbs-down"></i>
						</button>
						<i type="number" id="input2" value="0" name="" style="font-size: 25px; color: #ff0000; width: 50px; border: none; background: none; pointer-events: none; " ></i>

					</div>
				</div>
			</div>
			
		</div>
		<!-- // post sidebar -->
	</div>
</div>
<!-- // scripts -->
<script>
$(document).ready(function(){
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('0');
     load_comment();
    }
   }
  })
 });

 load_comment();

 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }

 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
 
});
</script>
<script type="text/javascript">

var input1 = 0;
var input2 = 0;

function initiateLikes () {
	var likeStr = localStorage.getItem("input1");
	if(likeStr == undefined) {
		localStorage.setItem("input1", 0);
		input1 = 0;

	}else{
		input1 = parseInt(likeStr);


	}
	document.getElementById("input1").innerHTML = input1;
}

function doClick() {
	input1 += 1;
	localStorage.setItem("input1", input1);
	document.getElementById("input1").innerHTML = input1;
}

document.getElementById("likebtn").onclick = doClick;
initiateLikes();


function initiateDisLikes () {
	var dislikeStr = localStorage.getItem("input2");
	if(dislikeStr == undefined) {
		localStorage.setItem("input2", 0);
		input2 = 0;
	}else{
		input2 = parseInt(dislikeStr);
	}
	document.getElementById("input2").innerHTML = input2;
}

function unClick() {
	input2 += 1;
	localStorage.setItem("input2", input2);
	document.getElementById("input2").innerHTML = input2;
	input2.style.color = "#ff0000";
}

document.getElementById("dislikebtn").onclick = unClick;
initiateDisLikes();


</script>

<!-- // content -->

<?php include( ROOT_PATH . '/footer.php'); ?>