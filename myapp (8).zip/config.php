<?php 
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/20/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //***Config/Database Connection********/
	session_start();

	// connect to database
	$conn = mysqli_connect("trial10-mysqldbserver.mysql.database.azure.com", "Warren", "Techn9ne", "completeblogphp");

	if (!$conn) {
		die("Error connecting to database: " . mysqli_connect_error());
	}
    // define global constants

	define ('ROOT_PATH', realpath(dirname(__FILE__)));
	define('BASE_URL', 'https://trial10.azurewebsites.net/myapp/');
?>