<?php
	//**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/21/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //*****Search Results Page**********/
//experacts an array of $person, Display the results in a table
include('config.php');


//$posts = array;
?>
<html>

<head>
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Averia+Serif+Libre|Noto+Serif|Tangerine" rel="stylesheet">
	<!-- Styling for public area -->
	<link rel="stylesheet" href="public_styling.css">
	<meta charset="UTF-8">
		<title>Warren Blog Search Results| Home </title>
</head>
<body>
	<div class="container">
		<div class="navbar">

			<div class="logo_div">
				<a href="index.php"><h1>Warren Blog</h1></a>
			</div>
			<form action="searchHandler.php">
				<ul>
		
	  				<li><input type ="text" name ="name" class="searchbar" placeholder="Search..."></input></li>
	  				<li><input type ="submit" class="search_btn" value="search"></input></li>

	  				<li><a class="active" href="home_page.html">Home</a></li>
	  				<li><a href="index.php">Main Menu</a></li>
	  				<li><a href="login.php">Log In </a></li>
	  				<li><a href="register.php">Registration</a></li>
				</ul>
			</form>
		</div>
		<?php if (isset($_SESSION['user']['username'])) { ?>
		<div class="logged_in_info">
			<span>welcome <?php echo $_SESSION['user']['username'] ?></span>
			|
			<span><a href="logout.php">logout</a></span>
		</div>
		<?php }?>
		<div class="banner">
			<div class="welcome_msg">
				<h1>Today's Inspiration</h1>
				<p> 
			    	One day your life <br> 
			    	will flash before your eyes. <br> 
			    	Make sure it's worth watching. <br>
				<span>~ Gerard Way</span>
				</p>
			</div>
		</div>

		<div class="content">
			<h3 class="content-title"><?php  echo "<br>You Searched for: " . $_GET['name'] . "<br>"; ?></h3>
    		<h2 class="content-title">Search Results</h2>
			<hr>
		
			<?php foreach ($posts as $post): ?>
				<div class="post" >
					<img src="<?php echo BASE_URL . '/images/' . $post['image']; ?>" class="post_image" alt="">
					<!-- Added this if statement... -->
					<?php if (isset($post['topic']['name'])): ?>
						<a 
							href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $post['topic']['id'] ?>"
							class="btn category">
							<?php echo $post['topic']['name'] ?>
						</a>
					<?php endif ?>

					<a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
						<div class="post_info">
							<h3><?php echo $post['title'] ?></h3>
							<div class="info">
								<span><?php echo date("F j, Y ", strtotime($post["created_at"])); ?></span>
								<span class="read_more">Read more...</span>
							</div>
						</div>
					</a>
				</div>
			<?php endforeach ?>
	
    <!--<h3><?php/*  echo "<br>You Searched for: " . $_GET['name'] . "<br>";*/ ?></h3>
    <h2>Search Results</h2>
	<table>
	<thead>
	<th>
	ID
	</th>
	<th>
	Title
	</th>
	<th>
	Body
	</th>
	</thead>-->
			<?php 
			for ($x = 0; $x < count($posts); $x++){
    
    			echo "<tr>";
    	//example of the array
    	//$posts[0]['title'] = "5 Habits that can improve your life";*/
    	//echo $posts['title'];
    
    	/*echo "<td>".$posts[$x]['id']. "</td>";
    	echo "<td>".$posts[$x]['title']. "</td>";
    	echo "<td>".$posts[$x]['body']. "</td>";
    	echo "</tr>";*/
    

			}
			?>
	

		</div>
	</div>


</body>

<div class="footer">
	<p>MyViewers &copy; <?php echo date('Y'); ?></p>
</div>
		<!-- // footer -->


	<!-- // container -->
